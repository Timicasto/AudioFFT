#ifndef AUDIOFFT_CAPTURE_H
#define AUDIOFFT_CAPTURE_H


void startCapture(const std::string& name);

#endif //AUDIOFFT_CAPTURE_H
