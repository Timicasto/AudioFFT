//

#ifndef AUDIOFFT_ENGINE_H
#define AUDIOFFT_ENGINE_H


#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include "Device.h"

class Engine {

public:
	static void loop(GLFWwindow *pWwindow);
};


#endif //AUDIOFFT_ENGINE_H
