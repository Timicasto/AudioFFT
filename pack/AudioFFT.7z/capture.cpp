#include <cstdio>
#include <alsa/asoundlib.h>
#include <string>
#include "capture.h"

void startCapture(const std::string& name) {

	while (1) {

	}
}
